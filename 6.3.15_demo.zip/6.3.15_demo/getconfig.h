#pragma once
#include <string>

using namespace std;

string getConfig(string title, string cfgName);
